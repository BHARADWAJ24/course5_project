package com.upgrad.hirewheels.practice;

public interface UserBalanceInterface {

    double getBalance();
}
