package com.upgrad.HireWheels.service;

import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements com.upgrad.HireWheels.service.AdminService {

}
