package com.upgrad.HireWheels.service;

public interface InitService {
    void start();
}
