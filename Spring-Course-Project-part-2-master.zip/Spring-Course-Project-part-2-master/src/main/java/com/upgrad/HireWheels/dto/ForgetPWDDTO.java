package com.upgrad.HireWheels.dto;

import lombok.Data;

@Data
public class ForgetPWDDTO {
    String email;
    String mobileNo;
    String password;
}
