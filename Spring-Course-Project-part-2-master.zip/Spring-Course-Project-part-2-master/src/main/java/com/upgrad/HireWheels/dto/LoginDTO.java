package com.upgrad.HireWheels.dto;
import lombok.Data;

@Data
public class LoginDTO {
    String email;
    String password;
}
