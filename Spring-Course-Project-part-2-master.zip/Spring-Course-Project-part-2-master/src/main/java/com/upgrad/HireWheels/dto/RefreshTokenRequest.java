package com.upgrad.HireWheels.dto;

import lombok.Data;


@Data
public class RefreshTokenRequest {
    private String refreshToken;
}