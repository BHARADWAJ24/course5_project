package com.upgrad.HireWheels.service;

public interface AdminService {

}
